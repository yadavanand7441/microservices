package com.springboot.microservices.controllers;

import com.springboot.microservices.entity.Hotel;
import com.springboot.microservices.services.HotelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotels")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    private Logger logger= LoggerFactory.getLogger(Hotel.class);

    //create
    @PostMapping("/create_hotel")
    public ResponseEntity<Hotel>createHotel(@RequestBody Hotel hotel)
    {
        Hotel hotel1 = hotelService.createHotel(hotel);
        logger.info("hotel data added into DB");
        return ResponseEntity.ok(hotel1);
    }
    //fetch single data of hotel
    @GetMapping("/{id}")
    public ResponseEntity<Hotel>getSingleHotel(@PathVariable String id)
    {
        Hotel singleHotel = hotelService.getSingleHotel(id);
        logger.info("hotel data found");
        return ResponseEntity.ok(singleHotel);
    }
    //fetch list of data of Hotel
    @GetMapping(" ")
    public ResponseEntity<List<Hotel>>getListOfHotel()
    {
        List<Hotel> hotelList = hotelService.getAllHotel();
        logger.info("all hotel founded");
        return ResponseEntity.ok(hotelList);
    }



}