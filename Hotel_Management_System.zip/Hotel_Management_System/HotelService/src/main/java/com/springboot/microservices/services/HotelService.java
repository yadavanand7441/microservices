package com.springboot.microservices.services;


import com.springboot.microservices.entity.Hotel;
import com.springboot.microservices.exceptions.ResourceNotFoundException;
import com.springboot.microservices.repositories.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    public Hotel createHotel(Hotel hotel) {
        String hotelId = UUID.randomUUID().toString();
        hotel.setId(hotelId);
        Hotel hotel1 = hotelRepository.save(hotel);
        return hotel1;
    }

    public Hotel getSingleHotel(String id) {
        return hotelRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("hotel with given id is not present in DB" + id));
    }

    public List<Hotel> getAllHotel() {
        return hotelRepository.findAll();
    }
}