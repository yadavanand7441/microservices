package com.springboot.microservices.controllers;

import com.springboot.microservices.entity.User;
import com.springboot.microservices.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    Logger logger = LoggerFactory.getLogger(User.class);

    // adding user data into DB
    @PostMapping("/save")
    public ResponseEntity<?> saveUsere(@RequestBody User user) {
        try {
            User saveUser = userService.saveUser(user);
            logger.info("user data has been added int DB !");
            return ResponseEntity.ok(saveUser);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(Map.of("", "something is worng. please try again !"));
        }
    }

    // fetching all user from DataBase
    @GetMapping("/")
    public ResponseEntity<List<?>> listOfUsers() {
        try {
            List<User> listOfUser = userService.getListOfUser();
            logger.info("All user have been found from DB");
            return ResponseEntity.ok(listOfUser);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // fetching single user
    @GetMapping("/{userId}")
    public ResponseEntity<?> getSingleUser(@PathVariable("userId") String userId) {

        User singleUser = userService.getSingleUser(userId);
        logger.info("user found");
        return ResponseEntity.ok(singleUser);
//        try {
//            User singleUser = userService.getSingleUser(userId);
//            logger.info("user with given id " + userId + " has been found ");
//            return ResponseEntity.ok(singleUser);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.ok(Map.of("", "please try again"));
//        }

    }
}
