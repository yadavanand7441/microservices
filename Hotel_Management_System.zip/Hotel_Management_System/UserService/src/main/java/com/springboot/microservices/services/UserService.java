package com.springboot.microservices.services;

import com.springboot.microservices.entity.Hotel;
import com.springboot.microservices.entity.Rating;
import com.springboot.microservices.entity.User;
import com.springboot.microservices.exceptions.ResourceNotFoundException;
import com.springboot.microservices.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;

    public User saveUser(User user)
    {
        //Generate unique userId
        String randomUserId = UUID.randomUUID().toString();
        user.setUserId(randomUserId);
        return userRepository.save(user);
    }
    public List<User> getListOfUser()
    {
        return userRepository.findAll();
    }
    public User getSingleUser(String userId)
    {
        User user= userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("user with given id is not present in DB " + userId));

        Rating[] ratingOfUser=restTemplate.getForObject("http://RATING-SERVICE/ratings/users/"+user.getUserId(), Rating[].class);

        List<Rating> ratings = Arrays.stream(ratingOfUser).collect(Collectors.toList());
        ratings.stream().map(rating -> {
            // api call to hotel service
            //  http://localhost:8082/hotels/3b108d6e-f3a6-4364-bf9a-581bf14b8fa2
            ResponseEntity<Hotel> forEntity = restTemplate.getForEntity("http://HOTEL-SERVICE/hotels/" + rating.getHotelId(), Hotel.class);
            Hotel hotel = forEntity.getBody();
            // set the hotel to rating
            rating.setHotel(hotel);
            // return rating
            return hotel;
        }).collect(Collectors.toList());
        user.setRatings(ratings);
        return user;
    }
}
