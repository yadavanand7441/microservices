package com.springboot.microservices.controllers;

import com.springboot.microservices.entity.Rating;
import com.springboot.microservices.services.RatingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ratings")
public class RatingController {

    @Autowired
    private RatingService ratingService;

    private Logger logger = LoggerFactory.getLogger(Rating.class);

    //create rating
    @PostMapping("/create_rating")
    public ResponseEntity<Rating> create(@RequestBody Rating rating) {
        Rating serviceRating = ratingService.createRating(rating);
        logger.info("rating created successfully");
        return ResponseEntity.ok(serviceRating);
    }

    //fetching all rating that is given by user to the hotel
    @GetMapping("/")
    public ResponseEntity<List<Rating>> getRating() {
        List<Rating> ratingList = ratingService.getRating();
        logger.info("rating found");
        return ResponseEntity.ok(ratingList);
    }
    //fetching rating by userId
    @GetMapping("/users/{userId}")
    public ResponseEntity<List<Rating>>getRatingByUserId(@PathVariable String userId)
    {
        List<Rating> ratingByUserId = ratingService.getRatingByUserId(userId);
        logger.info("rating is given by userId");
        return ResponseEntity.ok(ratingByUserId);
    }
    //fetching rating by hotelId
    @GetMapping("/hotels/{hotelId}")
    public ResponseEntity<List<Rating>>getRatingByHotelId(@PathVariable String hotelId)
    {
        List<Rating> ratingByHotelId = ratingService.getRatingByHotelId(hotelId);
        logger.info("rating is given by hotelId");
        return ResponseEntity.ok(ratingByHotelId);
    }
}