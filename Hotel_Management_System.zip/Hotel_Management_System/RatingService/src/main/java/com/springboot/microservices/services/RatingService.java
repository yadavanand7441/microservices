package com.springboot.microservices.services;

import com.springboot.microservices.entity.Rating;
import com.springboot.microservices.exceptions.ResourceNotFoundException;
import com.springboot.microservices.repositories.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class RatingService {

    @Autowired
    private RatingRepository ratingRepository;

    //create rating
    public Rating createRating(Rating rating)
    {
        String randomRatingId = UUID.randomUUID().toString();
        rating.setRatingId(randomRatingId);
        return ratingRepository.save(rating);
    }
    //fetch rating
    public List<Rating> getRating()
    {
        return ratingRepository.findAll();
    }
    //fetching single rating
    //fetch single rating
    public Rating getSingleRating(String ratingId)
    {
        Rating rating=ratingRepository.findById(ratingId).orElseThrow(()->new ResourceNotFoundException("rating with given id "+ratingId+" is not present in DB"+ratingId));
        return rating;
    }
    //fetch rating by userId
    public List<Rating>getRatingByUserId(String userId)
    {
        return ratingRepository.getRatingByUserId(userId);
    }
    //fetch rating by hotelId
    public List<Rating>getRatingByHotelId(String hotelId)
    {
        return ratingRepository.getRatingByHotelId(hotelId);
    }
}
